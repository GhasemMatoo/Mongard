db = db.getSiblingDB("test_db");

db.createUser({
    user: "matoo",
    pwd: "Mg1368e",
    roles: [
      {
        role: 'readWrite', 
        db: 'test_db'
      },
    ],
  });
db.createUser({
    user: "matoo",
    pwd: "Mg1368",
    roles: [
      {
        role: 'dbOwner', dbOwner
        db: 'test_db'
      },
    ],
  });


